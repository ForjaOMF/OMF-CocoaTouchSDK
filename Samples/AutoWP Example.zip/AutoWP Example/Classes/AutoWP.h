//
//  API_AutoWP.h
//  Cocoa Touch API AutoWP
//


#import <UIKit/UIKit.h>


@interface AutoWP : NSObject {

}

- (NSString *) SendAutoWP: (NSString *) login password: (NSString *) pass url: (NSString *) dir text: (NSString *) message;

@end
