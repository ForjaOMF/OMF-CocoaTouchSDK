//
//  Ejempo_AutoWPAppDelegate.h
//  Ejempo AutoWP
//


#import <UIKit/UIKit.h>

@class ViewController;

@interface Ejempo_AutoWPAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	ViewController *myViewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) ViewController *myViewController;

@end

