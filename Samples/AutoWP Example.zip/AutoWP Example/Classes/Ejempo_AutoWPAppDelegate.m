//
//  Ejempo_AutoWPAppDelegate.m
//  Ejempo AutoWP
//


#import "Ejempo_AutoWPAppDelegate.h"
#import "ViewController.h"

@implementation Ejempo_AutoWPAppDelegate

@synthesize window;
@synthesize myViewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	// Override point for customization after app launch
	ViewController *aViewController = [[ViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
	self.myViewController = aViewController;
	[aViewController release];
	
	UIView *controllersView = [myViewController view];
	
	[window addSubview:controllersView];
}


- (void)dealloc {
	[myViewController release];
	[window release];
	[super dealloc];
}

@end
