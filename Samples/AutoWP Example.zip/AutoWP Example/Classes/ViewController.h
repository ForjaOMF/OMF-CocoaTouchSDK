//
//  ViewController.h
//  Ejempo AutoWP
//


#import <UIKit/UIKit.h>


@interface ViewController : UIViewController {
	
	IBOutlet UILabel *lUsuario;
	IBOutlet UILabel *lPassword;
	IBOutlet UILabel *lUrl;
	IBOutlet UILabel *lMensaje;
	IBOutlet UILabel *lDebug;
	IBOutlet UITextField *textUsuario;
	IBOutlet UITextField *textPassword;
	IBOutlet UITextField *textUrl;
	IBOutlet UITextField *textMensaje;
	IBOutlet UITextField *textDebug;
}

@property (nonatomic, retain) UITextField *textUsuario;
@property (nonatomic, retain) UITextField *textPassword;
@property (nonatomic, retain) UITextField *textUrl;
@property (nonatomic, retain) UITextField *textMensaje;
@property (nonatomic, retain) UITextField *textDebug;
@property (nonatomic, retain) UILabel *lUsuario;
@property (nonatomic, retain) UILabel *lPassword;
@property (nonatomic, retain) UILabel *lUrl;
@property (nonatomic, retain) UILabel *lMensaje;
@property (nonatomic, retain) UILabel *lDebug;

- (IBAction)enviar: (id)sender;
@end
