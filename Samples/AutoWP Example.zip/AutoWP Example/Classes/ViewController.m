//
//  ViewController.m
//  Ejempo AutoWP
//


#import "ViewController.h"
#import "AutoWP.h"


@implementation ViewController

@synthesize textUsuario;
@synthesize textPassword;
@synthesize textUrl;
@synthesize textMensaje;
@synthesize textDebug;
@synthesize lUsuario;
@synthesize lPassword;
@synthesize lUrl;
@synthesize lMensaje;
@synthesize lDebug;


/*
 This method is not invoked if the controller is restored from a nib file.
 All relevant configuration should have been performed in Interface Builder.
 If you need to do additional setup after loading from a nib, override -loadView.
 */
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Initialization code
		
		self.title = NSLocalizedString(@"ViewController", @"ViewController title");
	}
	return self;
}


- (void)loadView {
	// Don't invoke super if you want to create a view hierarchy programmatically
	[super loadView];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[textUsuario release];
	[textPassword release];
	[textUrl release];
	[textMensaje release];
	[textDebug release];
	[lUsuario release];
	[lPassword release];
	[lUrl release];
	[lMensaje release];
	[lDebug release];
	[super dealloc];
}

- (IBAction)enviar:(id)sender {
	
	NSString * salida;
	AutoWP * WapPush = [AutoWP alloc];
	
	salida = [WapPush SendAutoWP:textUsuario.text password:textPassword.text url:textUrl.text text:textMensaje.text];
	textDebug.text = salida;
}

@end
