//
//  Ejemplo_CopiagendaAppDelegate.h
//  Ejemplo Copiagenda
//


#import <UIKit/UIKit.h>

@class MainViewController;

@interface Ejemplo_CopiagendaAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	MainViewController *mainviewController;
		
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) MainViewController *mainviewController;

@end

