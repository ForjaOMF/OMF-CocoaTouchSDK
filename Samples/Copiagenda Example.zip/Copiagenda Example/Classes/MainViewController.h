//
//  MainViewController.h
//  Ejemplo Copiagenda
//


#import <UIKit/UIKit.h>


@interface MainViewController : UIViewController {
	IBOutlet UITextField *tuser;
	IBOutlet UITextField *tpassword;
	IBOutlet UILabel *luser;
	IBOutlet UILabel *lPass;
	IBOutlet UILabel *lTitulo;
	IBOutlet UITextField *tresult;
	IBOutlet UITextField *tresult2;
}

@property (nonatomic, retain) UITextField *tuser;
@property (nonatomic, retain) UITextField *tpassword;
@property (nonatomic, retain) UITextField *tresult;
@property (nonatomic, retain) UITextField *tresult2;

@property (nonatomic, retain) UILabel *luser;
@property (nonatomic, retain) UILabel *lPass;
@property (nonatomic, retain) UILabel *lTitulo;

- (IBAction)pushbutton1:(id)sender;
//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation;

@end
