//
//  MainViewController.m
//  Ejemplo Copiagenda
//


#import "MainViewController.h"
#import "Copiagenda.h"


@implementation MainViewController

@synthesize tuser;
@synthesize tpassword;
@synthesize luser;
@synthesize lPass;
@synthesize lTitulo;
@synthesize tresult;
@synthesize tresult2;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Initialization code
	}
	return self;
}

- (IBAction)pushbutton1:(id)sender {
	Copiagenda * Contacts;
	Contacts = [Copiagenda alloc];
	NSString * publicar;
	NSDictionary * contactos;
	contactos = [Contacts RetrieveContacts:tuser.text password:tpassword.text];
	publicar = [NSString stringWithFormat:@"%@",[Contacts SearchByName:@"rico" contacts:contactos]];
	[Contacts dealloc];
	tresult2.text = publicar; 
}

- (BOOL) textFieldShouldReturn: (UITextField *)theTextField {
	if (theTextField == tpassword) {
		[tpassword resignFirstResponder];
	} else if (theTextField == tuser) {
		[tuser resignFirstResponder];
	} else if (theTextField == tresult) {
		[tresult resignFirstResponder];
	} else if (theTextField == tresult2) {
		[tresult2 resignFirstResponder];
    }
	return YES;
}
/*
 Implement loadView if you want to create a view hierarchy programmatically
- (void)loadView {
}
 */


// If you need to do additional setup after loading the view, override viewDidLoad.
- (void)viewDidLoad {
	CGRect frame = CGRectMake(20, 200, 280, 200);
	UITextField *atextField = [[UITextField alloc] initWithFrame:frame];
	self.tresult2 = atextField;
	[atextField release];
	
	//tresult2.textAlignment = UITextAlignmentCenter;
	tresult2.borderStyle = UITextBorderStyleRoundedRect;
	tresult2.autocapitalizationType = UITextAutocapitalizationTypeWords;
	tresult2.keyboardType = UIKeyboardTypeASCIICapable;
	tresult2.returnKeyType = UIReturnKeyDone;
	//tresult2.delegate = self;
	[self.view addSubview:tresult2];
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[tuser release];
	[tpassword release];
	[luser release];
	[lPass release];
	[lTitulo release];

	[super dealloc];
}


@end
