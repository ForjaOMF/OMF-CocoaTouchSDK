//
//  Localizame_ExampleAppDelegate.h
//  Localizame Example
//
//  Created by Francisco on 08/05/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;


@interface Localizame_ExampleAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	MainViewController * mainviewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) MainViewController *mainviewController;

@end

