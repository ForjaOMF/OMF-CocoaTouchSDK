//
//  Localizame_ExampleAppDelegate.m
//  Localizame Example
//


#import "Localizame_ExampleAppDelegate.h"
#import "MainViewController.h"

@implementation Localizame_ExampleAppDelegate

@synthesize window;
@synthesize mainviewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	// Override point for customization after app launch
	MainViewController *aViewController = [[MainViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
	self.mainviewController = aViewController;
	[aViewController release];
	
	UIView *controllersView = [mainviewController view];
	[window addSubview:controllersView];
	
}


- (void)dealloc {
	[mainviewController release];
	[window release];
	[super dealloc];
}

@end
