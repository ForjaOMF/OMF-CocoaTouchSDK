//
//  MainViewController.h
//  Localizame Example
//


#import <UIKit/UIKit.h>


@interface MainViewController : UIViewController {

	IBOutlet UITextField * tuser;
	IBOutlet UITextField * tpassword;
	IBOutlet UILabel * luser;
	IBOutlet UILabel * lpassword;
	IBOutlet UITextView *texto;
}

@property (nonatomic,retain) UITextField * tuser;
@property (nonatomic,retain) UITextField * tpassword;
@property (nonatomic,retain) UILabel * luser;
@property (nonatomic,retain) UILabel * lpassword;
@property (nonatomic,retain) UITextView * texto;

- (IBAction) buttonLocate: (id)sender;

@end
