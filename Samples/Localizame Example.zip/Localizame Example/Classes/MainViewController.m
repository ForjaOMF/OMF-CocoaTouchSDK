//
//  MainViewController.m
//  Localizame Example
//


#import "MainViewController.h"
#import "Localizame.h"


@implementation MainViewController

@synthesize tuser;
@synthesize luser;
@synthesize tpassword;
@synthesize lpassword;
@synthesize texto;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Initialization code
	}
	return self;
}

/*
 Implement loadView if you want to create a view hierarchy programmatically
- (void)loadView {
}
 */

/*
 If you need to do additional setup after loading the view, override viewDidLoad.
- (void)viewDidLoad {
}
 */


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

- (BOOL) textFieldShouldReturn: (UITextField *)theTextField {
	if (theTextField == tpassword) {
		[tpassword resignFirstResponder];
	} else if (theTextField == tuser) {
		[tuser resignFirstResponder];
	} 
	return YES;
}

- (void)dealloc {
	[tuser release];
	[tpassword release];
	[luser release];
	[lpassword release];
	[texto release];
	[super dealloc];
}

- (IBAction) buttonLocate: (id)sender {
	
	Localizame * API = [Localizame alloc];
	if ([API Login: tuser.text password: tpassword.text]) {
		texto.text = [API Locate:tuser.text];
	} else {
		texto.text = [NSString stringWithFormat:@"Error al localzar a %s", tuser.text];
	}
}



@end
