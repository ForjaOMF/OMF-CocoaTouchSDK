//
//  MMSSender_ExampleAppDelegate.h
//  MMSSender Example
//


#import <UIKit/UIKit.h>

@class MyViewController;

@interface MMSSender_ExampleAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	MyViewController *myviewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) MyViewController *myviewController;

@end

