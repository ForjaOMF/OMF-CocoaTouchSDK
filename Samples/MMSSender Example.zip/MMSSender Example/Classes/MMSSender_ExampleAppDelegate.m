//
//  MMSSender_ExampleAppDelegate.m
//  MMSSender Example
//


#import "MyViewController.h"
#import "MMSSender_ExampleAppDelegate.h"


@implementation MMSSender_ExampleAppDelegate

@synthesize window;
@synthesize myviewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	// Override point for customization after app launch
	MyViewController *aViewController = [[MyViewController alloc] initWithNibName:@"ControllerView" bundle: [NSBundle mainBundle]];
	self.myviewController = aViewController;
	[aViewController release];
	
	UIView *controllerView = [myviewController view];
	[window addSubview:controllerView];
}


- (void)dealloc {
	[myviewController release];
	[window release];
	[super dealloc];
}

@end
