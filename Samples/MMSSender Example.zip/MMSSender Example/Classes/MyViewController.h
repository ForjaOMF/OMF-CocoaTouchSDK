//
//  MyViewController.h
//  MMSSender Example
//


#import <UIKit/UIKit.h>


@interface MyViewController : UIViewController {
	IBOutlet UITextField * tto;
	IBOutlet UITextField * tsubject;
	IBOutlet UITextView * tmessage;
	IBOutlet UILabel * lresult;
	

}

@property (nonatomic, retain) UITextField *tto;
@property (nonatomic, retain) UITextField *tsubject;
@property (nonatomic, retain) UITextView *tmessage;
@property (nonatomic, retain) UILabel * lresult;

- (IBAction) clickSend: (id) sender;

@end
