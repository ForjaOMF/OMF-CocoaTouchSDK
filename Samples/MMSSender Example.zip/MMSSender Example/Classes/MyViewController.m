//
//  MyViewController.m
//  MMSSender Example
//


#import "MyViewController.h"
#import "MMSSender.h"


@implementation MyViewController

@synthesize tto;
@synthesize tsubject;
@synthesize tmessage;
@synthesize lresult;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Initialization code
	}
	return self;
}

- (BOOL) textFieldShouldReturn: (UITextField *)theTextField {
	if (theTextField == tto) {
		[tto resignFirstResponder];
	} else if (theTextField == tsubject) {
		[tsubject resignFirstResponder];
	}
	return YES;
}


- (IBAction) clickSend: (id) sender {
	//Insert user, password and image.
	NSString * user = @"6xxxxxxxx";
	NSString * pass = @"xxxxxx";
	MMSSender * APIMMS;
	APIMMS = [MMSSender alloc];
	if ([APIMMS Login: user Password: pass]) {
		[APIMMS InsertImage:@"xxx.jpg" Path:@"xxx.jpg"];
		if ([APIMMS SendMessage:tsubject.text To:tto.text Text:tmessage.text])
			lresult.text = @"OK";
		[APIMMS Logout];
		
	} else
		lresult.text = @"Error";
	
	
}


/*
 Implement loadView if you want to create a view hierarchy programmatically*/
//- (void)loadView {
	
//}
 

/*
 If you need to do additional setup after loading the view, override viewDidLoad.*/
/*- (void)viewDidLoad {
	
}*/
 


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[super dealloc];
}


@end
