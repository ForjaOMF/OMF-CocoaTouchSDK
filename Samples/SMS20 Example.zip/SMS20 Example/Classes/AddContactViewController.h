//
//  AddContactViewController.h
//  SMS2 iPhone
//


#import <UIKit/UIKit.h>
#import "SMS20.h";

@interface AddContactViewController : UIViewController {
	
	IBOutlet UITextField *contactNumber;
	NSString *User;
	SMS20 *API;
	

}
@property (nonatomic, retain) UITextField *contactNumber;
@property (nonatomic, retain) NSString *User;


- (IBAction) addContactAction: (id) sender;

@end
