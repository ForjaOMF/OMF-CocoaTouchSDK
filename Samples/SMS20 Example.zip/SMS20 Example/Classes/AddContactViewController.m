//
//  AddContactViewController.m
//  SMS2 iPhone
//


#import "AddContactViewController.h"
#import "SMS20.h"


@implementation AddContactViewController

@synthesize contactNumber, User;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Initialization code
		self.title = @"Login";
	}
	return self;
}

/*
 Implement loadView if you want to create a view hierarchy programmatically
- (void)loadView {
}
 */

/*
 If you need to do additional setup after loading the view, override viewDidLoad.
- (void)viewDidLoad {
}
 */

- (BOOL)textFieldShouldReturn:(UITextField *) theTextField {
	if (theTextField == contactNumber) {
		[contactNumber resignFirstResponder];
	} 
	return YES;
}


- (IBAction) addContactAction: (id) sender{
	API = [[[SMS20 alloc] init] retain];
	[API AddContact:User Contact:contactNumber.text];
	
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[super dealloc];
}


@end
