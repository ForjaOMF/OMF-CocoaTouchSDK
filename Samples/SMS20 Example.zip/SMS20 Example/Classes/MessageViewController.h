//
//  MessageViewController.h
//  SMS2 iPhone
//

 
#import <UIKit/UIKit.h>
#import "SMS20.h"

@interface MessageViewController : UIViewController <UISearchBarDelegate> {
	
	UIView *containerView;	
	SMS20Contact *contact;
	SMS20 *API;
	SMS20Helper *API_AUX;
	IBOutlet UITextView *sms20messages;
	IBOutlet UISearchBar *mySearchBar;
	IBOutlet UILabel *number;
	NSString *conversacion;
	uint AlertAction;
	NSString *AlertUser, *AlertTrans;
	NSTimer *temporizador;
	NSString *SMSUser;
}

@property (nonatomic,retain) UISearchBar *mySearchBar;
@property (nonatomic,retain) UITextView *sms20messages;
@property (nonatomic,retain) UILabel *number;
@property (nonatomic,retain) UIView *containerView;
@property (nonatomic,retain) SMS20Contact *contact;
@property (nonatomic,retain) NSString *conversacion;
@property (nonatomic,retain) NSString *SMSUser;

@end
