//
//  MessageViewController.m
//  SMS2 iPhone
//

 
#import "MessageViewController.h"
#import "SMS20.h"
#import <MediaPlayer/MediaPlayer.h>

@implementation MessageViewController

@synthesize containerView, contact, sms20messages, mySearchBar,conversacion, SMSUser, number;

- (id)init {
	if (self = [super init]) {
		//self.title = @"Conversacion";		
	}
	return self;
}


/*- (void)loadView {	
}
*/

/*
- (void)flipCurrentView {
}
*/

 - (void)viewDidLoad {
	 API = [[[SMS20 alloc] init] retain];
	 API_AUX = [[SMS20Helper alloc] retain];
	 number.text = contact.userID;
	 temporizador = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(backgroundThreadFire:) userInfo:nil repeats:YES];
	 mySearchBar.autocorrectionType = UITextAutocorrectionTypeNo;
	 
}

-(void)backgroundThreadFire:(id)sender {
	// do repeated work every one second here
	NSString * polling = [API Polling];
	NSString *limit = @"<NewMessage>";
	NSRange rango = [polling rangeOfString:limit];
	if (rango.length != 0) {
		NSRange limite;
		NSString *user, *mensaje;
		limit = [API_AUX NewMessage:polling];
		limite = [limit rangeOfString:@"wv"];
		mensaje = [limit substringToIndex:limite.location];
		user = [limit substringFromIndex:limite.location];
		if ([user isEqualToString:contact.userID]) {
			user = contact.alias;
			limit = [NSString stringWithFormat:@"%@ dice:\r\n %@\r\n",user,mensaje];
			NSLog(limit);
			sms20messages.text = [sms20messages.text stringByAppendingString:limit];
			NSRange range;
			range = [sms20messages.text rangeOfString:limit];
			range.location = sms20messages.text.length;
			[sms20messages scrollRangeToVisible:range];
			
		} else {
			limit = [NSString stringWithFormat:@"Mensaje de %@",user];
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:limit message:mensaje delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
			[alert show];
			[alert release];
			
		}
		
	} else {
		limit = @"<PresenceNotification-Request>";
		rango = [polling rangeOfString:limit];
		if (rango.length != 0) {
			NSLog(@"Notificacion de presencia"); //Ignore in this view
		} else {
			limit = @"<PresenceAuth-Request>";
			rango = [polling rangeOfString:limit];
			if (rango.length != 0) {
				NSString *notificacion;
				NSLog(@"Autorización de presencia");
				notificacion = [API_AUX PresenceAuth:polling];
				NSString *userAuth, *trans, *temp;
				NSRange rango;
				temp = @"wv";
				rango = [notificacion rangeOfString:temp];
				userAuth = [notificacion substringFromIndex:rango.location];
				trans = [notificacion substringToIndex:rango.location];
				NSString *mensaje = [NSString stringWithFormat:@"Autorizas a %@ a ver tu estado?",userAuth];
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Autorización de presencia" message:mensaje delegate:self cancelButtonTitle:@"Ignorar" otherButtonTitles:@"Aceptar", nil];
				[alert show];
				[alert release];
				AlertAction = 2;
				AlertUser = [[NSString stringWithString:userAuth] retain];
				AlertTrans = [[NSString stringWithString:trans] retain];
			} else {
				NSLog(@"Sin novedad");
			}
		}
	}
		
}

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex == 0)
	{
		//NSLog(@"cancel");
		//Ignore message
	}
	else
	{
		NSLog(@"ok");
		switch (AlertAction) {
			case 1: 
				AlertAction = 0;
				break;
			case 2:
				[API AuthorizeContact:AlertUser Transaction:AlertTrans];
				AlertAction = 0;
				break;
		}		
	}
}

-(void)backgroundThreadTerminate {
	[temporizador invalidate];
	CFRunLoopStop([[NSRunLoop currentRunLoop] getCFRunLoop]);
}

- (void)dealloc {
	[API_AUX release];
	[sms20messages release];
	[super dealloc];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	[mySearchBar resignFirstResponder];
	conversacion = [NSString stringWithFormat:@"Yo:\r\n %@",mySearchBar.text];
	sms20messages.text = [sms20messages.text stringByAppendingString:conversacion];
	sms20messages.text = [sms20messages.text stringByAppendingString:@"\r\n"];
	[API SendMessage:SMSUser Destination:[contact userID] Message:mySearchBar.text];
	NSRange range;
	range = [sms20messages.text rangeOfString:mySearchBar.text];
	[sms20messages scrollRangeToVisible:range];
	
	
}

// called when cancel button pressed
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
	[mySearchBar resignFirstResponder];
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
	mySearchBar.text = @"";
}


- (void)viewDidDisappear:(BOOL)animated {
	[self backgroundThreadTerminate];
}

@end
