//
//  SMS2_iPhoneAppDelegate.h
//  SMS2 iPhone
//

#import <UIKit/UIKit.h>
#import "SMS20.h"
#import "MessageViewController.h"
#import "AddContactViewController.h"

@class SetupViewController;

@interface SMS2_iPhoneAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet UINavigationController *navigationController;
	IBOutlet UINavigationItem *navigationItemBar;
	IBOutlet UINavigationBar *navigationBarSMS;
	IBOutlet UIToolbar *toolbar;
	IBOutlet UIBarButtonItem *addContact, *setup;
	SMS20 *API;
	SMS20Helper *API_AUX;
	NSMutableArray *array;
	NSDictionary *contactos;
	IBOutlet UITableView *table;
	NSTimer *temporizador;
	MessageViewController *messageController;
	SetupViewController *setupController;
	AddContactViewController *addContactController;
	uint gen, config;
	uint AlertAction;
	uint edit;
	NSString *AlertUser, *AlertTrans;
	NSString *SMSUser, *SMSPassword; 
	NSString *SMSAlias;
}
@property (nonatomic, retain) NSString *AlertUser;
@property (nonatomic, retain) NSString *AlertTrans;
@property (nonatomic, retain) UINavigationItem *navigationItemBar;
@property (nonatomic, retain) UINavigationBar *navigationBarSMS;
@property (nonatomic, retain) NSString *SMSUser;
@property (nonatomic, retain) NSString *SMSPassword;
@property (nonatomic, retain) NSString *SMSAlias;
@property (nonatomic, retain) UIBarButtonItem *setup;
@property (nonatomic, retain) UIBarButtonItem *addContact;
@property (nonatomic, retain) UIToolbar *toolbar;
@property (nonatomic, retain) AddContactViewController *addContactController;
@property (nonatomic, retain) MessageViewController *messageController;
@property (nonatomic, retain) SetupViewController *setupController;
@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) UINavigationController *navigationController;
@property (nonatomic, retain) NSDictionary *contactos;


@end

