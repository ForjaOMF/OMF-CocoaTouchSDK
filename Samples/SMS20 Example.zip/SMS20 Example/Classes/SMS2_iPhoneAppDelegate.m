//
//  SMS2_iPhoneAppDelegate.m
//  SMS2 iPhone
//

#import "SMS2_iPhoneAppDelegate.h"
#import "SetupViewController.h"
#import "MessageViewController.h"
#import "AddContactViewController.h"

@implementation SMS2_iPhoneAppDelegate

@synthesize window;
@synthesize navigationController, navigationItemBar, navigationBarSMS;
@synthesize contactos;
@synthesize messageController, toolbar, setupController, addContactController;
@synthesize addContact, setup, SMSUser, SMSPassword, SMSAlias, AlertUser, AlertTrans;

- (void) editAction: (id) sender {
	if (edit == 0) {
		[table setEditing:YES animated:YES];
		edit = 1;
	} else {
		[table setEditing:NO animated:YES];
		edit = 0;
	}
}

- (void) addcontactAction: (id) sender {
	addContactController = [[AddContactViewController alloc] initWithNibName:@"AddContactView" bundle:[NSBundle mainBundle]];
	addContactController.User = SMSUser;
	addContactController.title = @"Añadir contacto";
	[[self navigationController] pushViewController:addContactController animated:YES];
	config = 2;
	
}

- (void) setupAction: (id) sender {
	setupController = [[SetupViewController alloc] initWithNibName:@"SetupView" bundle:[NSBundle mainBundle]];
	setupController.title = @"Login";
	[[self navigationController] pushViewController:setupController animated:YES];
	config = 1;
	
}

- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	
	SMSUser = [NSString stringWithFormat:@""];
	SMSPassword = [NSString stringWithFormat:@""];
	SMSAlias = [[NSString stringWithFormat:@""] retain];
	setup = [[UIBarButtonItem alloc] initWithTitle:@"Login" style:UIBarButtonItemStyleBordered target:self action:@selector(setupAction:)];
	
	
	NSArray *toolbarItem = [NSArray arrayWithObjects:setup,nil];
	[toolbar setItems:toolbarItem animated:YES];
	[setup release];

	array = [NSMutableArray new];
	API = [[[SMS20 alloc] init] retain];
	API_AUX = [[SMS20Helper alloc] retain];
    [window addSubview:navigationController.view];
	[window makeKeyAndVisible];
	gen = 1;
	config = 0;
	edit = 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [array count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *identity = @"mainCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identity];
	if (cell == nil) 
	{
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:identity] autorelease];
	}
	
	
	SMS20Contact *contacts = [array objectAtIndex:indexPath.row];
	NSString *Record = contacts.alias;
	uint presence = contacts.presence;
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	UIImage *imagen; 
	cell.text = Record;
	switch (presence) {
		case 0:
			//imagen = [[UIImage imageNamed:@"12-6AM.png"] retain];
			imagen = [[UIImage imageNamed:@"contactNopresent2.jpg"] retain];

			break;
		case 1:
			imagen = [[UIImage imageNamed:@"contactPresent2.jpg"] retain];
			break;
		default:
			break;
	}
	cell.image = imagen;
 	return cell;
	
}

-(void)backgroundThreadTerminate {
	[temporizador invalidate];
	CFRunLoopStop([[NSRunLoop currentRunLoop] getCFRunLoop]);
}

- (void)viewDidLoad {
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	id Value = [array objectAtIndex:indexPath.row];
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
	messageController = [[MessageViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
	messageController.contact = Value;
	messageController.title = [Value valueForKey:@"alias"];
	messageController.SMSUser = SMSUser;
	[[self navigationController] pushViewController:messageController animated:YES];

	
}


- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
	if (gen == 1) {
		temporizador = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(backgroundThreadFire:) userInfo:nil repeats:YES];
		gen = 0;
	} else {
		[self backgroundThreadTerminate];
		gen = 1;
	}
	if (config == 1) {
		SMSUser = setupController.Usuario;
		SMSPassword = setupController.Password;
		SMSAlias = setupController.Alias;
		config = 0;
		NSString *sessionid = [API Login:SMSUser Password:SMSPassword];
		if (sessionid == nil) {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Login incorrecto" delegate:self cancelButtonTitle:@"Aceptar" otherButtonTitles: nil];
			[alert show];
			[alert release];
		} else {
			addContact = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addcontactAction:)];
			NSArray *toolbarItem = [NSArray arrayWithObjects:addContact,nil];
			[toolbar setItems:toolbarItem animated:YES];
			[addContact release];
			contactos = [[API Connect:SMSUser Nickname:SMSAlias] retain];
			if ([contactos count] != 0) {
				id key;
				NSEnumerator * numerator = [contactos keyEnumerator];
				while (key = [numerator nextObject]) {
					SMS20Contact *Contact;
					Contact = [contactos objectForKey:key];
					NSLog(Contact.alias);
					[array addObject:Contact];
				}
				UIBarButtonItem *editButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editAction:)];
				navigationItemBar.rightBarButtonItem = editButton;
				navigationController.navigationItem.rightBarButtonItem = editButton;
				[table reloadData];
			}
		}
	} else if (config == 2) {
			config = 0;
	}
}


-(void)backgroundThreadFire:(id)sender {
	//Polling
	uint encontrado = 0;
	NSString * polling = [API Polling];
	NSLog(polling);
	NSString *limit = @"<NewMessage>";
	NSRange rango = [polling rangeOfString:limit];
	if (rango.length != 0) {
		NSRange limite;
		NSString *user, *mensaje;
		limit = [API_AUX NewMessage:polling];
		limite = [limit rangeOfString:@"wv"];
		mensaje = [limit substringToIndex:limite.location];
		user = [limit substringFromIndex:limite.location];
		uint i = 0;
		uint j = [array count];
		while (i != j) {
			SMS20Contact *temp1 = [array objectAtIndex:i];
			if ([user isEqualToString:temp1.userID]) {
				limit = [NSString stringWithFormat:@"Nuevo mensaje de %@",temp1.alias];
				i = j;
				AlertUser = temp1.alias;
			} else {
				i++;
			}
		}
		AlertAction = 1;
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:limit message:mensaje
													   delegate:self cancelButtonTitle:@"Ignorar" otherButtonTitles:@"Responder", nil];
		[alert show];
		[alert release];
		
	} else {
		limit = @"<PresenceNotification-Request>";
		rango = [polling rangeOfString:limit];
		if (rango.length != 0) {
			NSDictionary* actualizar = [NSDictionary dictionary];
			actualizar = [API_AUX PresenceNotification:polling];
			if ([actualizar count] != 0) {
				uint i = 0;
				uint j = [array count];
				while (i != j) {
					SMS20Contact *temp1 = [array objectAtIndex:i];
					SMS20Contact *temp2 = [actualizar objectForKey:temp1.userID];
					if (temp2 != nil) {
						encontrado = 1;
						if (temp2.alias == @"") {
							temp2.alias = temp1.alias;
						}
						if (temp2.presence == 3)
							temp2.presence = temp1.presence;
						
						[array replaceObjectAtIndex:i withObject:temp2];
					} 
					i++;
				}
				if (encontrado == 0) {
					//new contact to add
					if ([actualizar count] == 1) { 
						NSArray *nuevo = [actualizar allValues];
						SMS20Contact *newContact = [nuevo objectAtIndex:0];
						if (newContact.alias == @"") {
							//NSLog(@"Viene sin alias");
							NSString *tempname = newContact.userID;
							NSRange pos = [tempname rangeOfString:@"wv:"];
							newContact.alias = [tempname substringFromIndex:pos.location+3];
						}
						[array addObject:newContact];
					}
				}
				
				[table reloadData];
				
				}
		} else {
			limit = @"<PresenceAuth-Request>";
			rango = [polling rangeOfString:limit];
			if (rango.length != 0) {
				NSString *notificacion;
				notificacion = [API_AUX PresenceAuth:polling];
				NSString *userAuth, *trans, *temp;
				NSRange rango;
				temp = @"wv";
				rango = [notificacion rangeOfString:temp];
				userAuth = [notificacion substringFromIndex:rango.location];
				trans = [notificacion substringToIndex:rango.location];
				AlertAction = 2;
				AlertUser = [[NSString stringWithString:userAuth] retain];
				AlertTrans = [[NSString stringWithString:trans] retain];
				NSString *mensaje = [NSString stringWithFormat:@"Autorizas a %@ a ver tu estado?",userAuth];
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Autorizar a contacto" message:mensaje delegate:self cancelButtonTitle:@"Rechazar" otherButtonTitles:@"Aceptar", nil];
				[alert show];
				[alert release];
				
			} else {
				NSLog(@"Sin novedad ");
			}
		}
	}
	
}

//Delegate Action Sheet

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	// the user clicked one of the OK/Cancel buttons
}

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex == 0)
	{
		NSLog(@"cancel");
	}
	else
	{
		
		NSLog(@"ok");
		switch (AlertAction) {
			case 1:
				NSLog(@"AlertUser");
				uint i = 0;
				uint j = [array count];
				SMS20Contact *temp1;
				while (i != j) {
					temp1 = [array objectAtIndex:i];
					if ([AlertUser isEqualToString:temp1.alias]) {
						//NSLog(temp1.alias);
						i = j;
					} else {
						i++;
					}
				}
				messageController = [[MessageViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
				messageController.contact = temp1;
				messageController.SMSUser = SMSUser;
				messageController.title = temp1.alias;
				[[self navigationController] pushViewController:messageController animated:YES];
				AlertAction = 0;
				break;
			case 2:
				[API AuthorizeContact:AlertUser Transaction:AlertTrans];
				AlertAction = 0;
				break;
		}

	}
}


- (void)tableView:(UITableView *)tv commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    // If row is deleted, remove it from the list.
    if (editingStyle == UITableViewCellEditingStyleDelete) {
		id Value = [array objectAtIndex:indexPath.row];
		NSString *candidato = [Value valueForKey:@"userID"];		
		[API DeleteContact:SMSUser Contact:candidato];
		uint i = 0;
		uint j = [array count];
		SMS20Contact *temp1;
		while (i != j) {
			temp1 = [array objectAtIndex:i];
			if ([candidato isEqualToString:temp1.userID]) {
				[array removeObject:temp1];
				i = j;
			} else {
				i++;
			}
		}
		[table reloadData];
		[table setEditing:NO animated:YES];
    }
}

- (void)dealloc {
	[messageController release];
	[API_AUX release];
	[API Disconnect];
	[API release];
    [navigationController release];
	[window release];
	[super dealloc];
}


@end
