//
//  SetupViewController.h
//  SMS2 iPhone
//


#import <UIKit/UIKit.h>
#import "SMS20.h"

@interface SetupViewController : UIViewController {

	IBOutlet UITextField *Tuser, *Tpassword;
	IBOutlet UITextField *Text2;
	NSString *Usuario, *Password, *Alias;

}

@property (nonatomic, retain) UITextField *Tuser;
@property (nonatomic, retain) UITextField *Tpassword;
@property (nonatomic, retain) UITextField *Text2;

@property (nonatomic, retain) NSString *Usuario;
@property (nonatomic, retain) NSString *Password;
@property (nonatomic, retain) NSString *Alias;

- (IBAction) clickSetting: (id) sender;

@end

