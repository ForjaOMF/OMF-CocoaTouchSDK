//
//  SMS2_iPhoneAppDelegate.m
//  SMS2 iPhone
//


#import "SetupViewController.h"

@implementation SetupViewController

@synthesize Tuser, Tpassword, Usuario, Password, Alias;
@synthesize Text2;
/*
 Implement loadView if you want to create a view hierarchy programmatically
- (void)loadView {
}
 */

/*
 Implement viewDidLoad if you need to do additional setup after loading the view.
*/
 - (void)viewDidLoad {
	 Usuario = [NSString stringWithFormat:@""];
	 Password = [NSString stringWithFormat:@""];
	 Alias = [NSString stringWithFormat:@""];
	[super viewDidLoad];
}
 
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Initialization code
		self.title =@"Login";
	}
	return self;
}

- (id)init
{
	self = [super init];
	if (self)
	{
		// this title will appear in the navigation bar
		self.title = @"Login";
	}
	return self;
}

- (IBAction) clickSetting: (id) sender {
	Usuario = [NSString stringWithString:Tuser.text];
	Password = Tpassword.text;
	Alias = [NSString stringWithString:Text2.text];
}

- (BOOL)textFieldShouldReturn:(UITextField *) theTextField {
	if (theTextField == Tuser) {
		[Tuser resignFirstResponder];
	} else if (theTextField == Tpassword) {
		[Tpassword resignFirstResponder];
	} else if (theTextField == Text2) {
		[Text2 resignFirstResponder];
	}
	return YES;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[super dealloc];
}

@end
