//
//  SendSMSAppDelegate.h
//  SendSMS
//
//  Created by Francisco on 22/09/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SendSMSViewController;

@interface SendSMSAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet SendSMSViewController *viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) SendSMSViewController *viewController;

@end

