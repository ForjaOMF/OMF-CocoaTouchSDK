//
//  SendSMSViewController.h
//  SendSMS
//
//  Created by Francisco on 22/09/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendSMSViewController : UIViewController {
	IBOutlet UITextField *textUsuario;
	IBOutlet UITextField *textPassword;
	IBOutlet UITextField *textDestinatario;
	IBOutlet UITextField *textMensaje;
	IBOutlet UILabel *textDebug;
}

@property (nonatomic, retain) UITextField *textUsuario;
@property (nonatomic, retain) UITextField *textPassword;
@property (nonatomic, retain) UITextField *textDestinatario;
@property (nonatomic, retain) UITextField *textMensaje;
@property (nonatomic, retain) UILabel *textDebug;

- (IBAction)accionEnviar:(id)sender;

@end

