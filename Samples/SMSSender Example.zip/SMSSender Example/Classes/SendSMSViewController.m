//
//  SendSMSAppDelegate.m
//  SendSMS
//
//  Created by Francisco on 22/09/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "SendSMSViewController.h"
#import "SMSSender.h"

@implementation SendSMSViewController

@synthesize textUsuario;
@synthesize textPassword;
@synthesize textDestinatario;
@synthesize textMensaje;
@synthesize textDebug;


- (IBAction)accionEnviar:(id)sender {
	
	SMSSender * SMSopen;
	SMSopen = [SMSSender alloc];
	NSString * publish;
	publish = [NSString stringWithFormat:[SMSopen SendMessage:textUsuario.text pass:textPassword.text destination:textDestinatario.text text:textMensaje.text]];
	textDebug.text=publish;
	[SMSopen dealloc]; 
	
}


/*
 Implement loadView if you want to create a view hierarchy programmatically
- (void)loadView {
}
 */

/*
 Implement viewDidLoad if you need to do additional setup after loading the view.
- (void)viewDidLoad {
	[super viewDidLoad];
}
 */

- (BOOL) textFieldShouldReturn: (UITextField *)theTextField {
	if (theTextField == textUsuario) {
		[textUsuario resignFirstResponder];
	} else if (theTextField == textPassword) {
		[textPassword resignFirstResponder];
	} else if (theTextField == textMensaje) {
		[textMensaje resignFirstResponder];
	} else if (theTextField == textDestinatario) {
		[textDestinatario resignFirstResponder];
	}
	return YES;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[textUsuario release];
	[textPassword release];
	[textDestinatario release];
	[textMensaje release];
	[super dealloc];
}

@end
